from django.db import models

class Category(models.Model):

    name = models.CharField('Nome', max_length=100)
    slug = models.SlugField('Atalho')

    class Meta:
        verbose_name = 'Categoria'
        verbose_name_plural = 'Categorias'

    def __str__(self):
        return self.name


class Course(models.Model):
	name = models.CharField('Nome', max_length=100)
	slug = models.SlugField('Atalho')
	category = models.ForeignKey(Category, verbose_name='Categoria', null=True)
	description = models.TextField('Descrição', blank=True)
	start_date = models.DateField(
		'Data de Início', null=True, blank=True)
	image = models.ImageField(upload_to='courses/images', verbose_name = 'Imagem',
		null=True, blank=True)
	created_at = models.DateTimeField('Criado em', auto_now_add=True)
	upload_at = models.DateTimeField('Atualizado em', auto_now=True)
	price = models.DecimalField(
        'Preço', default=0, decimal_places=2, max_digits=8
    )